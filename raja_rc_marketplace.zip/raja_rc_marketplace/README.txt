RAJA RC Marketplace prototype

This is a working browser prototype for the RAJA RC marketplace concept.

Core model:
- Sellers list products/services.
- Buyers search and contact/buy.
- RAJA RC can earn a configurable commission on completed transactions.

Before Play Store launch, add:
- User accounts
- Seller verification/KYC
- Product image uploads
- Real payment gateway
- Order management
- Refund/dispute system
- Admin dashboard
- Terms/privacy/refund policies
- Android packaging, signing and Play Console setup

This prototype does NOT process real money.
